import { Bookuser } from './bookuser';

describe('Bookuser', () => {
  it('should create an instance', () => {
    expect(new Bookuser()).toBeTruthy();
  });
});
