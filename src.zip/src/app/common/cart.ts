export class Cart {

    constructor(public cartId: number,
        public bookId: number,
        public userId: number) { }
}
