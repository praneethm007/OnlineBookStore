import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Books } from 'src/app/common/books';
import { BooksservicesService } from 'src/app/services/booksservices.service';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {
  books:Books[];
  cartId:number;

  constructor(private bookservice:BooksservicesService,private route:Router, private activatedRoute:ActivatedRoute) { }

  ngOnInit(): void {

  }
  viewCart(){
    
  }
  delete(){

  }
}
