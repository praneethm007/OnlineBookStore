import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-firstpage',
  templateUrl: './firstpage.component.html',
  styleUrls: ['./firstpage.component.css']
})
export class FirstpageComponent implements OnInit {
  name: string = "";

  constructor(private route: Router, private activaeRoute: ActivatedRoute) { }

  ngOnInit(): void {    
    
  }

  login() {
    this.route.navigateByUrl("loginpage");
  }
 
}
