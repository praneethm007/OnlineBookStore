import { BookCategory } from './book-category';

describe('BookCategory', () => {
  it('should create an instance', () => {
    expect(new BookCategory()).toBeTruthy();
  });
});
