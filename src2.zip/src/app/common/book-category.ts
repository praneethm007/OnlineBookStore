export class BookCategory {

    constructor(private catogeoryid: number,
        public categoryName: string) { }
}
