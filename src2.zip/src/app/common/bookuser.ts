export class Bookuser {

    Bookuser(){}
    constructor(public bbuserId: number,
        public firstName: string, 
        public lastName: string, 
        public bbuserName: string, 
        public bbuserPassword: string,
        public bbuserAddress1: string,
        public bbuserAddress2: string) { }
}
